import LRA.VolumeI.Relations.Equivalence.EquivalenceRelation
import LRA.VolumeI.Identity.Model.Theory
import LRA.VolumeI.Set.Interface.Membership

namespace LRA.Relation

open LRA.Set

universe u v

/-!
Equivalence classes, generically over any set backend with separation.

Everything here separates from an explicit ambient set -- no universal set
is involved -- so this vocabulary is available for Enderton sets and
predicate sets alike.
-/

section EquivalenceClasses

variable {Element : Type u} {SetObject : Type v}
variable [Membership Element SetObject]

/-- A set `classSet` is the equivalence class of `representative` in
`ambient` when its members are exactly the ambient elements related to that
representative.

Logical form:

```lean
def IsEquivalenceClassOf
    (classSet ambient : SetObject)
    (relation : Endorelation Element)
    (representative : Element) : Prop :=
  ∀ candidate : Element,
    candidate ∈ classSet ↔
      candidate ∈ ambient ∧ relation candidate representative
```
-/
def IsEquivalenceClassOf
    (classSet ambient : SetObject)
    (relation : Endorelation Element)
    (representative : Element) : Prop :=
  ∀ candidate : Element,
    candidate ∈ classSet ↔
      candidate ∈ ambient ∧ relation candidate representative

section WithSeparation

variable [HasSeparation Element SetObject]

/-- The equivalence class of a representative with respect to a relation.

Logical form:

```lean
def EquivalenceClass
    (ambient : SetObject)
    (relation : Endorelation Element)
    (representative : Element) : SetObject :=
  HasSeparation.separation ambient
    (fun candidate => relation candidate representative)
```
-/
def EquivalenceClass
    (ambient : SetObject)
    (relation : Endorelation Element)
    (representative : Element) : SetObject :=
  HasSeparation.separation ambient
    (fun candidate => relation candidate representative)

section Laws

variable [SeparationLaws Element SetObject]
variable [ExtensionalityLaw Element SetObject]

/--
**[Theorem — EquivalenceClassExists]**

For each representative, its equivalence class exists.

Logical form:

```lean
theorem EquivalenceClassExists
    (ambient : SetObject)
    (relation : Endorelation Element)
    (representative : Element) :
    LRA.Identity.Exists
      (fun classSet : SetObject =>
        IsEquivalenceClassOf classSet ambient relation representative)
```
-/
theorem EquivalenceClassExists
    (ambient : SetObject)
    (relation : Endorelation Element)
    (representative : Element) :
    LRA.Identity.Exists
      (fun classSet : SetObject =>
        IsEquivalenceClassOf classSet ambient relation representative) := by
  sorry

/--
**[Theorem — EquivalenceClassUnique]**

An equivalence class is uniquely determined by its representative and
membership specification.

Logical form:

```lean
theorem EquivalenceClassUnique
    (ambient : SetObject)
    (relation : Endorelation Element)
    (representative : Element) :
    LRA.Identity.Unique
      (fun classSet : SetObject =>
        IsEquivalenceClassOf classSet ambient relation representative)
```
-/
theorem EquivalenceClassUnique
    (ambient : SetObject)
    (relation : Endorelation Element)
    (representative : Element) :
    LRA.Identity.Unique
      (fun classSet : SetObject =>
        IsEquivalenceClassOf classSet ambient relation representative) := by
  sorry

/--
**[Theorem — EquivalenceClassExistsAndUnique]**

For each representative, there is exactly one equivalence class
satisfying the memberwise specification.

Logical form:

```lean
theorem EquivalenceClassExistsAndUnique
    (ambient : SetObject)
    (relation : Endorelation Element)
    (representative : Element) :
    LRA.Identity.ExistsAndUnique
      (fun classSet : SetObject =>
        IsEquivalenceClassOf classSet ambient relation representative)
```
-/
theorem EquivalenceClassExistsAndUnique
    (ambient : SetObject)
    (relation : Endorelation Element)
    (representative : Element) :
    LRA.Identity.ExistsAndUnique
      (fun classSet : SetObject =>
        IsEquivalenceClassOf classSet ambient relation representative) := by
  sorry

/--
**[Theorem — EquivalenceClassMembershipIff]**

The constructed equivalence class satisfies its defining membership
specification.

Logical form:

```lean
theorem EquivalenceClassMembershipIff
    (ambient : SetObject)
    (relation : Endorelation Element)
    (representative candidate : Element) :
    candidate ∈ EquivalenceClass ambient relation representative ↔
      candidate ∈ ambient ∧ relation candidate representative
```
-/
theorem EquivalenceClassMembershipIff
    (ambient : SetObject)
    (relation : Endorelation Element)
    (representative candidate : Element) :
    candidate ∈ EquivalenceClass ambient relation representative ↔
      candidate ∈ ambient ∧ relation candidate representative := by
  sorry

/--
**[Theorem — RelatedRepresentativesHaveSameEquivalenceClass]**

Two representatives determine the same class when they are related.

Logical form:

```lean
theorem RelatedRepresentativesHaveSameEquivalenceClass
    {relation : Endorelation Element}
    (relationIsEquivalence : EquivalenceRelation relation)
    {firstRepresentative secondRepresentative : Element}
    (representativesRelated :
      relation firstRepresentative secondRepresentative) :
    ∀ ambient : SetObject,
      EquivalenceClass ambient relation firstRepresentative =
        EquivalenceClass ambient relation secondRepresentative
```
-/
theorem RelatedRepresentativesHaveSameEquivalenceClass
    {relation : Endorelation Element}
    (relationIsEquivalence : EquivalenceRelation relation)
    {firstRepresentative secondRepresentative : Element}
    (representativesRelated :
      relation firstRepresentative secondRepresentative) :
    ∀ ambient : SetObject,
      EquivalenceClass ambient relation firstRepresentative =
        EquivalenceClass ambient relation secondRepresentative := by
  sorry

end Laws

end WithSeparation

end EquivalenceClasses

end LRA.Relation
