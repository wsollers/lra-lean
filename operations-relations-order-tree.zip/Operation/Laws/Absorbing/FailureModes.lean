import LRA.VolumeI.Map.Operation.Laws.Absorbing.Definition

namespace LRA.Map.Operation.Laws.Absorbing

open LRA.Map.Operation

universe u

/-- Failure of a right-absorbing claim. -/
def FailsRightAbsorbing {Carrier : Type u}
    (operation : BinaryEndoOperation Carrier)
    (candidate : Carrier) : Prop :=
  Not (RightAbsorbing operation candidate)

/-- Failure of a left-absorbing claim. -/
def FailsLeftAbsorbing {Carrier : Type u}
    (operation : BinaryEndoOperation Carrier)
    (candidate : Carrier) : Prop :=
  Not (LeftAbsorbing operation candidate)

/-- The first projection operation on booleans. -/
def BooleanFirstProjection : BinaryEndoOperation Bool :=
  fun left _ => left

/-- The second projection operation on booleans. -/
def BooleanSecondProjection : BinaryEndoOperation Bool :=
  fun _ right => right

/--
**[Failure Mode — BooleanFirstProjectionLeftAbsorbingButNotRightAbsorbing]**

A concrete left absorber need not be a right absorber.
-/
theorem BooleanFirstProjectionLeftAbsorbingButNotRightAbsorbing :
    LeftAbsorbing BooleanFirstProjection false /\
      FailsRightAbsorbing BooleanFirstProjection false := by
  sorry

/--
**[Failure Mode — BooleanSecondProjectionRightAbsorbingButNotLeftAbsorbing]**

A concrete right absorber need not be a left absorber.
-/
theorem BooleanSecondProjectionRightAbsorbingButNotLeftAbsorbing :
    RightAbsorbing BooleanSecondProjection false /\
      FailsLeftAbsorbing BooleanSecondProjection false := by
  sorry

end LRA.Map.Operation.Laws.Absorbing
